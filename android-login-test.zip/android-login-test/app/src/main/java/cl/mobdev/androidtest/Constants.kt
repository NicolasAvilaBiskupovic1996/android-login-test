package cl.mobdev.androidtest

object Constants {
    const val NEW_USER_CODE = "El usuario se ha registrado con éxito"
    const val ERROR_TOKEN = "getIdToken() failed"
    const val ERROR_USER = "get currentUser failed"
    const val url_prod = "https://padok-bff.herokuapp.com"
}